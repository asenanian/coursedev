package com.mygdx.entities;

import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector3;
import com.mygdx.game.MyGdxGame;

public class Player extends Sphere {
	
	private float radians;
	
	private boolean left;
	private boolean right;
	private boolean up;
	
	private float maxSpeed;
	private float acceleration;
	private float deceleration;
	
	private float acceleratingTimer;
	
	public Player(float[] position, float[] velocity, float mass, float radius, ModelBuilder modelBuilder) {
		
		super(position, velocity, mass, radius, modelBuilder);
		x = MyGdxGame.WIDTH / 2;
		y = MyGdxGame.HEIGHT / 2;
		dx = velocity[0];
		dy = velocity[1];
		dz = velocity[2];
		maxSpeed = 300;
		acceleration = 200;
		deceleration = 10;
		
		radians = 0;
		rotationSpeed = 3;
		
	}
	
	
	public void setLeft(boolean b) { left = b; }
	public void setRight(boolean b) { right = b; }
	public void setUp(boolean b) { up = b; }
	
	public void update(float dt) {
		//System.out.println((float)dx*dt);
		instance.transform.translate(new Vector3((float)dx*dt,(float)dy*dt,(float)dz*dt));
		instance.calculateTransforms();
		
		// turning
		if (left) {
			//radians += rotationSpeed * dt;
		}
//		else if (right) {
//			radians -= rotationSpeed * dt;
//		}
//		
//		// accelerating
//		if (up) {
//			dx += MathUtils.cos(radians) * acceleration * dt;
//			dy += MathUtils.sin(radians) * acceleration * dt;
//			acceleratingTimer += dt;
//			if(acceleratingTimer > 0.1f) {
//				acceleratingTimer = 0;
//			}
//		}
//		
//		// deceleration
//		float vec = (float) Math.sqrt(dx * dx + dy * dy);
//		if (vec > 0) {
//			dx -= (dx / vec) * deceleration * dt;
//			dy -= (dy / vec) * deceleration * dt;
//		}
//		if (vec > maxSpeed) {
//			dx = (dx / vec) * maxSpeed;
//			dy = (dy / vec) * maxSpeed;
//		}
//		
//		// set position
//		x += dx * dt;
//		y += dy * dt;
//		
//		// set flame
////		if (up) {
////			setFlame();
////		}
////		
////		// screen wrap
//		wrap();
	}
	
	public void wrap() {
		if (x > MyGdxGame.WIDTH) {
			x = 0;
		} else if (x < 0) {
			x = MyGdxGame.WIDTH;
		} else if (y > MyGdxGame.HEIGHT) {
			y = 0;
		} else if (y < 0) {
			y = MyGdxGame.HEIGHT;
		}
	}
	
	public void draw(ModelBatch modelBatch, Environment environment) {
		modelBatch.render(instance,environment);
	}
}














